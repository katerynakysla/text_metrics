from text_metrics.moduls import (
    get_top_n_words,
    count_total_words,
    find_words_starting_with_vowel,
    find_words_starting_with_consonant,
    count_syllables,
    find_special_characters,
    special_character_frequency,
    top_special_characters,
    special_character_percentage,
    total_special_characters,
    find_numbers,
    count_numbers,
    find_punctuation,
    count_punctuation,
    punctuation_usage,
    find_emails,
    find_names,
    find_dates,
    find_urls
)

def main():
    user_text = input("Введіть текст для аналізу: ")

    # Аналіз тексту
    print("\n--- Результати аналізу ---")
    print("Найбільш вживані словоформи:", get_top_n_words(user_text))
    print("Загальна кількість слів:", count_total_words(user_text))
    print("Слова, що починаються на голосну:", find_words_starting_with_vowel(user_text))
    print("Слова, що починаються на приголосну:", find_words_starting_with_consonant(user_text))
    print("Кількість складів у тексті:", count_syllables(user_text))
    
    # Аналіз спеціальних символів
    print("\nСпеціальні символи:")
    print("Всі спеціальні символи:", find_special_characters(user_text))
    print("Частота спеціальних символів:", special_character_frequency(user_text))
    print("Топ спеціальних символів:", top_special_characters(user_text))
    print("Відсоток спеціальних символів:", special_character_percentage(user_text))
    print("Загальна кількість спеціальних символів:", total_special_characters(user_text))

    # Аналіз чисел і пунктуації
    print("\nАналіз чисел:")
    print("Знайдені числа:", find_numbers(user_text))
    print("Кількість чисел:", count_numbers(user_text))
    
    print("\nАналіз пунктуації:")
    print("Унікальні знаки пунктуації:", find_punctuation(user_text))
    print("Загальна кількість знаків пунктуації:", count_punctuation(user_text))
    print("Використання пунктуації:", punctuation_usage(user_text))

    # Пошук персональної інформації користувача
    print("\nДодатковий аналіз:")
    print("Знайдені електронні адреси:", find_emails(user_text))
    print("Знайдені імена:", find_names(user_text))
    print("Знайдені дати:", find_dates(user_text))
    print("Знайдені URL-адреси:", find_urls(user_text))

if __name__ == "__main__":
    main()