import re
from collections import Counter

#Модуль 1 

from collections import Counter
import re

def clean_and_lower_text(text):
    # Очищає текст від небажаних символів, залишаючи лише літери, та перетворює на нижній регістр. 
    cleaned_text = re.sub(r'[^а-яА-ЯєЄіІїЇоОуУаАеЕєЄґҐ]+', ' ', text)
    return cleaned_text.lower()

def get_top_n_words(text, n=5):
    # Повертає слова, які мають мінімум 4 літери та зустрічаються мінімум 2 рази.
    cleaned_text = clean_and_lower_text(text)
    tokens = cleaned_text.split()
    # Фільтруємо слова, залишаючи тільки ті, які мають 4 і більше літер
    filtered_tokens = [word for word in tokens if re.match(r'\b\w{4,}\b', word)]
    frequency = Counter(filtered_tokens)
    return [(word, count) for word, count in frequency.most_common(n) if count >= 2]

def count_total_words(text):
    # Повертає загальну кількість слів у тексті.
    cleaned_text = clean_and_lower_text(text)
    tokens = cleaned_text.split()
    return len(tokens)

def find_words_starting_with_vowel(text):
    # Знаходить всі слова, що починаються на голосну букву.
    cleaned_text = clean_and_lower_text(text)
    tokens = cleaned_text.split()
    vowels = 'аеєиіїоуюя'
    return [word for word in tokens if word[0] in vowels]

def find_words_starting_with_consonant(text):
    # Знаходить всі слова, що починаються на приголосну букву.
    cleaned_text = clean_and_lower_text(text)
    tokens = cleaned_text.split()
    consonants = 'бвгґджзйклмнпрстфхцчшщ'
    return [word for word in tokens if word[0] in consonants]

def count_syllables(text):
    # Рахує кількість складів у тексті, підраховуючи голосні букви.
    cleaned_text = clean_and_lower_text(text)
    vowels = 'аеєиіїоуюя'
    syllable_count = sum(1 for char in cleaned_text if char in vowels)
    return syllable_count

#Модуль 2

def find_special_characters(text):
    # Залишаємо лише специфіковані спеціальні символи
    special_character_pattern = r'[\@#$%^&*~`<>/\\|+=]'
    return re.findall(special_character_pattern, text)

def special_character_frequency(text):
    special_chars = find_special_characters(text)
    frequency = {}
    for char in special_chars:
        frequency[char] = frequency.get(char, 0) + 1
    return [f"{char}: {count}" for char, count in frequency.items()]  # Без обмеження на кількість

def top_special_characters(text, top_n=5):
    freq = special_character_frequency(text)
    # Фільтруємо лише ті символи, які з'являються більше одного разу
    filtered_freq = [f for f in freq if int(f.split(': ')[1]) > 1]
    return filtered_freq[:top_n]

def special_character_percentage(text):
    total_length = len(text)
    if total_length == 0:
        return 0
    special_chars = find_special_characters(text)
    return (len(special_chars) / total_length) * 100

def total_special_characters(text):
    return len(find_special_characters(text))

# Модуль 3

def find_numbers(text):
    numbers = re.findall(r'\d+', text)
    return numbers

def count_numbers(text):
    numbers = find_numbers(text)
    return len(numbers)

def find_punctuation(text):
    punctuation = re.findall(r'[^\w\s]', text)
    unique_punctuation = list(set(punctuation))  # Використовуємо set для унікальності
    return unique_punctuation

def count_punctuation(text):
    punctuation = find_punctuation(text)
    all_punctuation = re.findall(r'[^\w\s]', text)  # Знаходимо всі знаки пунктуації
    return len(all_punctuation)  # Повертаємо загальну кількість

def punctuation_usage(text):
    punctuation = re.findall(r'[^\w\s]', text)
    punctuation_count = Counter(punctuation)  # Підрахунок частоти знаків
    return dict(punctuation_count)  # Повертаємо як звичайний словник

# Модуль 4 

def find_emails(text):
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    result = re.findall(email_pattern, text)
    return result

def find_names(text):
    # Дозволяє літери та цифри, але не крапки після @
    names_pattern = r'@[a-zA-Zа-яА-ЯєЄіІїЇоОуУаАеЕ0-9]+'
    result = re.findall(names_pattern, text)
    return result

def find_dates(text):
    date_pattern = r'\b(?:\d{2}[./-]\d{2}[./-]\d{4}|\d{4}[./-]\d{2}[./-]\d{2})\b'
    result = re.findall(date_pattern, text)
    return result

def find_urls(text):
    url_pattern = r'https?://[^\s]+|www\.[^\s]+'
    result = re.findall(url_pattern, text)
    return result